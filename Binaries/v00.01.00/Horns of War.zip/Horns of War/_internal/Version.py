class Version(object):

    def __init__(self, rows = 0, cols = 0, tiles_dictionary = None):
        self.version = "00.00.05"

    def get_version(self):
        return self.version

