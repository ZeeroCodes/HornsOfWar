from MapEditor.App import App

if __name__ == '__main__':
    App()
    
        
