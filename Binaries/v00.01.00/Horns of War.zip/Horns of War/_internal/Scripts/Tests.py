from distutils.core import setup
help(setup)